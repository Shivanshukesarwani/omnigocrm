# Shivanshu CRM Suite

A self-hostable sales CRM designed around the workflow discussed in this chat:

- Lead → Contact → Customer conversion
- Native WhatsApp click-to-chat links with situation-based templates
- Native Android CRM app with the same core CRM features as the web app
- One-click calling from Android
- Call activity logging
- Private call-recording upload/storage with admin-only web access
- Follow-ups, tasks, tags, lead sources, assignment and dashboard
- Product/service and quotation foundations
- PHP/Laravel backend suitable for standard PHP hosting (no Node.js required at runtime)

## Important scope note
This bundle is a strong functional MVP/foundation, not a finished enterprise product. The phone call-recording capability is device/Android/OEM dependent; Android does not guarantee that a third-party app can capture both sides of every cellular call. Test it on the exact phones you will deploy, and obtain any consent required by applicable law.

## Stack

- Laravel 13 / PHP 8.3+
- MySQL/MariaDB in production; SQLite can be used locally
- Blade + lightweight CSS (no Node.js required to serve the production app)
- Native Android/Kotlin client
- REST API with hashed bearer tokens

## Folder structure

- `backend/` — Laravel application source
- `android/` — Android Studio project
- `docs/` — plain-language installation and deployment guides

## Recommended deployment path

1. Install PHP 8.3–8.5 and Composer on the Windows development machine.
2. Open `backend/` in VS Code.
3. Copy `.env.example` to `.env`.
4. Run Composer install and `php artisan key:generate`.
5. Create the local DB and run `php artisan migrate --seed`.
6. Test the web app locally.
7. Upload the Laravel application to your PHP hosting, with the hosting document root pointing to `backend/public`.
8. Build the Android app in Android Studio and set the API URL to your HTTPS CRM URL.

See `docs/START_HERE.md` before doing anything else.
