@echo off
setlocal
cd /d "%~dp0backend"

echo === Shivanshu CRM Windows Setup ===
php -v >nul 2>&1 || (echo PHP not found. Install PHP 8.3+ first.&pause&exit /b 1)
composer --version >nul 2>&1 || (echo Composer not found. Install Composer first.&pause&exit /b 1)

if not exist .env copy .env.example .env
if not exist database\database.sqlite type nul > database\database.sqlite

composer install
php artisan key:generate
php artisan migrate --seed
php artisan optimize

echo.
echo Demo login: admin@shivanshu.local / ChangeMe123!
echo Demo sales: admin@shivanshu.local is not a sales user; sales@shivanshu.local / ChangeMe123!
echo.
echo Starting local CRM at http://127.0.0.1:8000
php artisan serve
